﻿// Form1.cs
using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace PleaseWorkBro
{
    public partial class Form1 : Form
    {
        private string robloxPath = "C:\\Users\\lucia\\AppData\\Local\\Roblox\\Versions\\version-8950870ea20941f9\\RobloxPlayerBeta.exe";
        private CustomExploitAPI exploitAPI = new CustomExploitAPI();
        private bool isDragging = false;
        private Point lastPoint;

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool Wow64DisableWow64FsRedirection(ref IntPtr ptr);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool Wow64RevertWow64FsRedirection(IntPtr ptr);

        private Process robloxProcess;

        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "Currently Not Running Roblox";
            panel1.MouseDown += PanelMouseDown;
            panel1.MouseMove += PanelMouseMove;
            panel1.MouseUp += PanelMouseUp;
        }

        private void PanelMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                lastPoint = e.Location;
            }
        }

        private void PanelMouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                int deltaX = e.X - lastPoint.X;
                int deltaY = e.Y - lastPoint.Y;
                this.Location = new Point(this.Location.X + deltaX, this.Location.Y + deltaY);
            }
        }

        private void PanelMouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bool success = false;
            int attempts = 0;
            const int maxAttempts = 3;

            while (!success && attempts < maxAttempts)
            {
                // Close the current Roblox process
                foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
                {
                    process.Kill();
                }

                // Start the Roblox process as a 32-bit process
                IntPtr oldValue = IntPtr.Zero;
                try
                {
                    // Disable filesystem redirection to access the 32-bit Roblox executable
                    Wow64DisableWow64FsRedirection(ref oldValue);

                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.FileName = robloxPath; // Use saved Roblox pathway
                    startInfo.UseShellExecute = false; // Ensure not using shell execute
                    startInfo.CreateNoWindow = true; // Ensure no window is created

                    // Set the environment variable to force 32-bit process
                    startInfo.Arguments = $"set PROCESSOR_ARCHITECTURE=x86 && set PROCESSOR_ARCHITEW6432=x86 && {robloxPath}";

                    robloxProcess = Process.Start(startInfo);

                    // Wait for the process to start
                    robloxProcess.WaitForInputIdle();

                    textBox1.Text = "Running Roblox on 32-bit process";
                    success = true; // Mark success if process starts without exception
                }
                catch (Exception ex)
                {
                    attempts++;
                    if (attempts >= maxAttempts)
                    {
                        MessageBox.Show("Couldn't open Roblox as a 32-bit process. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                finally
                {
                    // Revert filesystem redirection to its original state
                    Wow64RevertWow64FsRedirection(oldValue);
                }
            }

            if (!success)
            {
                textBox1.Text = "Currently Not Running Roblox";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string script = fastColoredTextBox1.Text;
            exploitAPI.SendLuaScript(script);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (robloxProcess != null && !robloxProcess.HasExited)
            {
                robloxProcess.Kill();
            }
            Application.Exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (robloxProcess != null && !robloxProcess.HasExited)
            {
                robloxProcess.Kill();
            }
        }
    }
}
